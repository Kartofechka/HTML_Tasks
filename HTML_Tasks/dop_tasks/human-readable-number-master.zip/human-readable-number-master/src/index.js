module.exports = function toReadable(/* number */) {
  throw new Error('Not implemented');
};
