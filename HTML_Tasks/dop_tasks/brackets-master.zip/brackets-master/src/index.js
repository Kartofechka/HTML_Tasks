module.exports = function check(/* str, bracketsConfig */) {
  throw new Error('Not implemented');
};
