const { decorateObject } = require('../lib');
const { NotImplementedError } = require('../lib');

/**
 * Implement chainMaker object according to task description
 *
 */
const chainMaker = {
  getLength() {
    // Remove line below and write your code here
    throw new NotImplementedError('Not implemented');
  },
  addLink(/* value */) {
    // Remove line below and write your code here
    throw new NotImplementedError('Not implemented');
  },
  removeLink(/* position */) {
    // Remove line below and write your code here
    throw new NotImplementedError('Not implemented');
  },
  reverseChain() {
    // Remove line below and write your code here
    throw new NotImplementedError('Not implemented');
  },
  finishChain() {
    // Remove line below and write your code here
    throw new NotImplementedError('Not implemented');
  },
};

module.exports = {
  chainMaker,
};
