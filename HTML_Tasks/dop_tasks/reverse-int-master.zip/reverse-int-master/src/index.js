module.exports = function reverse(/* n */) {
  throw new Error('Not implemented');
};
